DROP TABLE IF EXISTS `#__hitproject`;
DROP TABLE IF EXISTS `#__hitsite`;
DROP TABLE IF EXISTS `#__hitcamp`;

DROP TABLE IF EXISTS `#__hitplaats`;
DROP TABLE IF EXISTS `#__hitkamp`;
